/*!
 * \file scheduler.c
 * \brief
 *  This file holds the scheduler code. 
 */

#include "kernel.h"

void
scheduler_called_from_system_call_handler(const register int schedule)
{
}

void
scheduler_called_from_timer_interrupt_handler(const register int thread_changed)
{
}
