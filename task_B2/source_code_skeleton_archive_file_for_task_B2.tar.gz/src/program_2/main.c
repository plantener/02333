/*! \file
 * 	\brief The third user program. It prints a message.
 *
 */

#include <scwrapper.h>

void
main(int argc, char* argv[])
{
 prints("Ta da!\n");
}
